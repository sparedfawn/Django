#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

int counter = 0;

void* function(void* arg) {

    pthread_mutex_lock(&mutex);

    for(int i = 0; i < *((int *)arg); i++) {

        counter++;
    }

    pthread_mutex_unlock(&mutex);
}

int main(int argc, char* argv[]) {

    int N = atoi(argv[1]);
    int ITER = atoi(argv[2]);
    pthread_t threads[100];
    int result;

    for(int i = 0; i < N; i++) {

        result = pthread_create(&threads[i], NULL, function, (void *)&ITER);

        if(result != 0) {

            exit(1);
        }
    }

    for(int i = 0; i < N; i++) {

        pthread_join(threads[i], NULL);
    }

    printf("Counter value: %d\n", counter);

    return 0;

}