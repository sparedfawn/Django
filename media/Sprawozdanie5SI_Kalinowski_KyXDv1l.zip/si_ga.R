library(GA)

# parametry
population_size = 50
pc = 0.5
pm = 0.1
iteration = 10

# funkcja wraz z limitami x, y
Rastrigin <- function(x, y)
{
  x^2 + sin(y)
}
x <- seq(0, 1, by = 0.1)
y <- seq(0, 3.14, by = 0.1)

# wykres funkcji w 3d, oraz rzutowanie 2d
f <- outer(x, y, Rastrigin)
persp3D(x, y, f, color.palette =  jet.colors)
filled.contour(x, y, f, color.palette =  jet.colors)

# funkcja monitorujaca przebieg realizacji algorytmu
monitor <- function(obj) 
{ 
  contour(x, y, f, drawlabels = FALSE, col = grey(0.5))
  title(paste("iteration =", obj@iter), font.main = 1)
  points(obj@population, pch = 20, col = 2)
  Sys.sleep(0.2)
}

# uruchomienie algorytmu
GA <- ga(
  type = "real-valued",
  fitness = function(x) + Rastrigin(x[1], x[2]),
  lower = c(0, 0),
  upper = c(1, 3.14),
  pcrossover = pc,
  popSize = population_size,
  maxiter = iteration,
  pmutation = pm,
  monitor = monitor
)

# wyswietlenie podsumowania
summary(GA)
plot(GA)

# naniesienie najlepszego wyniku na wykred 2d
filled.contour(x, y, f, color.palette = jet.colors, 
               plot.axes = { axis(1); axis(2); 
                 points(GA@solution[,1], GA@solution[,2], 
                        pch = 3, cex = 2, col = "white", lwd = 2) }
)
